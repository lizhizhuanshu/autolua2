local events = require "inputEvent"
print(Input)
-- Input:tap(128,764,120)
print(Input:swipe(432,1097,745,436,1000))
