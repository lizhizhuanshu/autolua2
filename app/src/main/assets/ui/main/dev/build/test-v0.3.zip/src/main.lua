sleep(2000)
-- UI:destroyFloatView(id)

