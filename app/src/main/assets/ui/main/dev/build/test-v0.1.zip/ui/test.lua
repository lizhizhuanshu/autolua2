
print("Hello world")

print("lizhi")
