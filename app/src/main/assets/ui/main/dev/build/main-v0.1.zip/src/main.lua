local dkjson = require "dkjson"
local uri = "file://view.lua"


local layoutParams = {
  width = 800,
  height = 800
}
-- print(uri)

local id = UI:createFloatView(uri,layoutParams)
print(id)
if id >0 then
  UI:showFloatView(id)
  print("---------")
end
local a = UI:takeSignal("lizhi",-1)
print(dkjson.encode(a))

-- UI:destroyFloatView(id)

